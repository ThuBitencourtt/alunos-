/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Telas;

import javax.swing.table.AbstractTableModel;
import dados.Aluno;
import dados.Sistema;
import dados.Turma;
import java.util.Collection;
import java.util.LinkedList;
import javax.swing.JOptionPane;

public class AlunoTableModel extends AbstractTableModel {

    private LinkedList<Aluno> dados = new LinkedList<Aluno>();
    private String[] colunas = {"Matricula", "Nome", "Fone"};

    public AlunoTableModel() {
        Sistema sistema = Sistema.getInstance();
        Turma turma = sistema.getTurma();
        JOptionPane.showMessageDialog(null, "Alunos na turma." + turma.getAlunos().size());
        Collection<Aluno> alunos = turma.getAlunos().values();
        for (Aluno aluno : alunos) {
            this.addRow(aluno);
        }
        
        JOptionPane.showMessageDialog(null, "Tamanho do model." + dados.size());
    }

    public void addRow(Aluno p) {
        this.dados.add(p);
        this.fireTableDataChanged();
    }

    public String getColumnName(int num) {
        return this.colunas[num];
    }

    @Override
    public int getRowCount() {
        return dados.size();
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
        switch (coluna) {
            case 0:
                return dados.get(linha).getMatricula();
            case 1:
                return dados.get(linha).getNome();
            case 2:
                return dados.get(linha).getFone();
        }
        return null;
    }
}
