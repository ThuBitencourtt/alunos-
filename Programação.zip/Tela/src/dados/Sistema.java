/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.util.LinkedList;
import java.util.logging.Logger;

/**
 *
 * @author thuani.bittencourtt
 */
public class Sistema {

    // se for ter varias turmas vai ter que mexer aqui...
    private static Sistema instance;
    private Turma turma = new Turma();

    private static final Logger LOG = Logger.getLogger(Sistema.class.getName());

    private Sistema() {
        turma.setAno(2017);
        turma.setSemestre(1);
        turma.setCurso("Engenharia de Software");
    }

    public Turma getTurma() {
        return turma;
    }

    public static final Sistema getInstance() {
        if (instance == null) {
            instance = new Sistema();
        }
        return instance;
    }

    public void gravarAlunos() {
        LinkedList<Aluno> values = getAlunosParaGravarNoDisco();
        // fazer a lógica para gravasr os dados da lista no disco
    }

    public void lerAlunosDoDisco() {
        LinkedList<Aluno> values;
        // fazer a lógica para ler os dados do disco
        setAlunosLidosDoDisco(null); // deveria passar values
    }

    public void setAlunosLidosDoDisco(LinkedList<Aluno> values) {
        values.forEach((value) -> {
            turma.incluirAluno(value);
        });
    }

    public LinkedList<Aluno> getAlunosParaGravarNoDisco() {
        LinkedList<Aluno> values = (LinkedList<Aluno>) turma.getAlunos().values();
        return values;
    }
}
